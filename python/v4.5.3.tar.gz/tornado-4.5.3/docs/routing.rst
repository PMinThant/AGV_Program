``tornado.routing`` --- Basic routing implementation
====================================================

.. automodule:: tornado.routing
   :members:
