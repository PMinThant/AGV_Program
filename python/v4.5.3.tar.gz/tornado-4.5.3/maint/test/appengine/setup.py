# Dummy setup file to make tox happy.  In the appengine world things aren't
# installed through setup.py
import distutils.core
distutils.core.setup()
